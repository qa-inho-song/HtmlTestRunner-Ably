# HtmlTestRunner-Ably

HtmlTestRunner-Ably is a customized version of HtmlTestRunner that adds exception handling when running on Python 3.10 and later versions.

## Installation

```bash
pip install HtmlTestRunner-Ably
