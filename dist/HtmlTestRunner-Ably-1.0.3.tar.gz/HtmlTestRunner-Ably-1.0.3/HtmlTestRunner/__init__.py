# -*- coding: utf-8 -*-
from .runner import HTMLTestRunner


__author__ = """Inho Song"""
__email__ = 'ablyqa@a-bly.com'
__version__ = '1.0.3'
